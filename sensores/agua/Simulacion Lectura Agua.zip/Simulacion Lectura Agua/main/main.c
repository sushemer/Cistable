#include <math.h>
#include <stdio.h>
#include <stdint.h>

#include "esp_system.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"

#define MODBUS_FRAME_SIZE 7
#define SAMPLE_PERIOD_MS 250
#define FILTER_WINDOW 24
#define PI 3.14159265358979323846f

#define TANK_LENGTH_M 3.0f
#define TANK_WIDTH_M 1.5f
#define TANK_HEIGHT_M 2.0f
#define MM_PER_M 1000.0f
#define US_GALLONS_PER_M3 264.172052f

typedef struct {
	uint8_t bytes[MODBUS_FRAME_SIZE];
} modbus_frame_t;

typedef struct {
	float samples[FILTER_WINDOW];
	size_t next;
	size_t count;
	float sum;
} moving_average_t;

static QueueHandle_t frame_queue;

static float uniform_random(void)
{
	return ((float)esp_random() + 1.0f) / 4294967297.0f;
}

/* Box-Muller transforma dos valores uniformes en ruido gaussiano. */
static float gaussian_noise(float standard_deviation)
{
	const float u1 = uniform_random();
	const float u2 = uniform_random();
	const float normal = sqrtf(-2.0f * logf(u1)) * cosf(2.0f * PI * u2);

	return normal * standard_deviation;
}

static uint16_t modbus_crc16(const uint8_t *data, size_t length)
{
	uint16_t crc = 0xFFFF;

	for (size_t index = 0; index < length; index++) {
		crc ^= data[index];
		for (uint8_t bit = 0; bit < 8; bit++) {
			crc = (crc & 1U) ? (crc >> 1) ^ 0xA001 : crc >> 1;
		}
	}

	return crc;
}

static void build_mock_frame(modbus_frame_t *frame, float elapsed_seconds)
{
	/* Nivel que baja lentamente, con oleaje lento y vibracion del motor. */
	const float base_level_mm = 1800.0f - elapsed_seconds * 0.35f;
	const float sloshing_mm = 300.0f * sinf(2.0f * PI * 0.08f * elapsed_seconds);
	const float simulated_level_mm = fmaxf(0.0f, fminf(2000.0f,
		base_level_mm + sloshing_mm + gaussian_noise(18.0f)));
	const uint16_t level_mm = (uint16_t)lroundf(simulated_level_mm);

	frame->bytes[0] = 0x01; // Direccion del sensor Modbus.
	frame->bytes[1] = 0x03; // Funcion: lectura de registros.
	frame->bytes[2] = 0x02; // Dos bytes de datos.
	frame->bytes[3] = (uint8_t)(level_mm >> 8);
	frame->bytes[4] = (uint8_t)(level_mm & 0xFF);
	const uint16_t crc = modbus_crc16(frame->bytes, MODBUS_FRAME_SIZE - 2);
	frame->bytes[5] = (uint8_t)(crc & 0xFF); // Modbus transmite CRC low byte primero.
	frame->bytes[6] = (uint8_t)(crc >> 8);
}

static int parse_level_mm(const uint8_t *buffer, size_t length, uint16_t *level_mm)
{
	if (buffer == NULL || length != MODBUS_FRAME_SIZE || level_mm == NULL ||
		buffer[0] != 0x01 || buffer[1] != 0x03 || buffer[2] != 0x02) {
		return 0;
	}

	/* Se ignora el CRC en esta prueba; HIGH y LOW forman el entero de milimetros. */
	*level_mm = ((uint16_t)buffer[3] << 8) | buffer[4];
	return 1;
}

static float moving_average_update(moving_average_t *filter, float sample)
{
	if (filter->count == FILTER_WINDOW) {
		filter->sum -= filter->samples[filter->next];
	} else {
		filter->count++;
	}

	filter->samples[filter->next] = sample;
	filter->sum += sample;
	filter->next = (filter->next + 1) % FILTER_WINDOW;
	return filter->sum / (float)filter->count;
}

static void calculate_volume(float level_mm, float *percentage, float *gallons)
{
	const float tank_height_mm = TANK_HEIGHT_M * MM_PER_M;
	const float clamped_level_mm = fmaxf(0.0f, fminf(tank_height_mm, level_mm));
	const float fill_fraction = clamped_level_mm / tank_height_mm;
	const float volume_m3 = TANK_LENGTH_M * TANK_WIDTH_M * TANK_HEIGHT_M * fill_fraction;

	*percentage = fill_fraction * 100.0f;
	*gallons = volume_m3 * US_GALLONS_PER_M3;
}

static void mock_uart_task(void *arg)
{
	TickType_t last_wake = xTaskGetTickCount();
	uint32_t sample_number = 0;

	(void)arg;
	for (;;) {
		modbus_frame_t frame;
		build_mock_frame(&frame, (float)sample_number * SAMPLE_PERIOD_MS / 1000.0f);
		xQueueSend(frame_queue, &frame, portMAX_DELAY);
		sample_number++;
		vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(SAMPLE_PERIOD_MS));
	}
}

static void processing_task(void *arg)
{
	moving_average_t filter = {0};
	modbus_frame_t frame;
	const TickType_t start = xTaskGetTickCount();

	(void)arg;
	printf("Tiempo_ms,Nivel_Crudo_mm,Nivel_Filtrado_mm,Porcentaje,Galones\n");
	for (;;) {
		if (xQueueReceive(frame_queue, &frame, portMAX_DELAY) == pdTRUE) {
			uint16_t raw_level_mm;
			if (parse_level_mm(frame.bytes, sizeof(frame.bytes), &raw_level_mm)) {
				const float filtered_level_mm = moving_average_update(&filter, (float)raw_level_mm);
				float percentage;
				float gallons;
				calculate_volume(filtered_level_mm, &percentage, &gallons);
				const uint32_t elapsed_ms = (uint32_t)(xTaskGetTickCount() - start) * portTICK_PERIOD_MS;

				printf("%lu,%u,%.2f,%.2f,%.2f\n",
					   (unsigned long)elapsed_ms, raw_level_mm, filtered_level_mm,
					   percentage, gallons);
			}
		}
	}
}

void app_main(void)
{
	frame_queue = xQueueCreate(4, sizeof(modbus_frame_t));
	if (frame_queue == NULL) {
		printf("Error: no se pudo crear la cola de tramas Modbus\n");
		return;
	}

	xTaskCreate(mock_uart_task, "mock_uart", 4096, NULL, 5, NULL);
	xTaskCreate(processing_task, "water_processing", 4096, NULL, 4, NULL);
}
